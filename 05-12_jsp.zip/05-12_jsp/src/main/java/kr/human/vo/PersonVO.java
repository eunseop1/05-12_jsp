package kr.human.vo;

import lombok.Data;

@Data
public class PersonVO {
	private String name;
	private int age;
	private String[] hobby;
	private boolean gender;
	private String ip; //없지만 내가 만들 부분
	
}
